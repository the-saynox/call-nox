
![Logo](https://999xprofit.com/dogs/logo.png)

[![instagram](https://img.shields.io/badge/CONTACT-TELEGRAM-blue)](https://t.me/shivayadavv)

[![instagram](https://img.shields.io/badge/CONTACT-INSTAGRAM-red)](https://instagram.com/shivaya.dav)

#                     DOGERAT

A multifunctional Telegram based Android RAT  without port forwarding.
## Features

 - Read all the files of Internal Storage
 - Delete files or folder from victim device
 - Download Any Media to your Device from Victims Device
 - Get system information of Victim Device
 - Retrieve the List of Installed Applications
 - Retrive SMS
 - Retrive Call Logs
 - Retrive Contacts
 - Click photos from victim device front/main camera
 - Send SMS
 - Keylogger {not working in android 11 or higher version}
- Record Audio
- Pre Binded with [Instagram Webview]
 - Runs In Background 
    - Auto Starts on restarting the device
    
 - No port forwarding needed

## Requirements
 - Glitch Account
 - [ApkEasy Tool](https://apk-easy-tool.en.lo4d.com/windows) ( For PC ) or 
[ApkTool Editor](https://999xprofit.com/dogs/apkeditor.apk) ( for Android)


## How to use
- Search  BotFather on Telegram
![App Screenshot](https://999xprofit.com/dogs/1.jpg)
- Creat a bot with any name/username
![App Screenshot](https://999xprofit.com/dogs/2.jpg)
- Copy your Bot token
![App Screenshot](https://999xprofit.com/dogs/3.jpg)
- Go to glitch.com click
- new project then glitch-hello-node
![App Screenshot](https://999xprofit.com/dogs/4.jpg)
- Delete all pre-available files {clcik on 3 dots}
- click on files and upload package.json, server.js
![App Screenshot](https://999xprofit.com/dogs/5.jpg)
- Paste your bot token in line 16 {beetwen ''}
![App Screenshot](https://999xprofit.com/dogs/6.jpg)
- Paste your chat id in line 15 
- (search userinfobot on telegram and send any msg you will
- get your chatid
![App Screenshot](https://999xprofit.com/dogs/7.jpg)
- click on previvew availble on bottom
- open in new window
![App Screenshot](https://999xprofit.com/dogs/8.png)
- if you see this type then copy url and close all tabs
![App Screenshot](https://999xprofit.com/dogs/9.jpg)
- now open Apkeditor select apk 
- go to following directory
![App Screenshot](https://999xprofit.com/dogs/10.jpg)
![App Screenshot](https://999xprofit.com/dogs/11.jpg)
- paste your glitch url 
```bash
  { 
  "host": "https://https://xxxx.glitch.me/", 
  "socket": "wss://xxxx.glitch.me/", 
  "webView": "https://google.com/" 
}
```
- note: In webview you can add any website 
- when victim will open apk given website will be open in apk
- must replace https to wss
- click on save, and go back
![App Screenshot](https://999xprofit.com/dogs/12.jpg)
- clcik on smail and wait 3/4 second
- Now build the apk
- and install in any phone
![App Screenshot](https://999xprofit.com/dogs/13.jpg)
- now go to BotFather clcik on your botusername
 - start your bot 
 - now you can monitor all device who will install the apk
![App Screenshot](https://999xprofit.com/dogs/15.jpg)

### ❤️Thank you Supporters❤️
[![Stargazers repo roster for @shivaya-dav/DogeRat](https://reporoster.com/stars/dark/shivaya-dav/DogeRat)](https://github.com/shivaya-dav/DogeRat/stargazers)
## 🔗 CONTACT
[![instagram](https://img.shields.io/badge/CONTACT-TELEGRAM-blue)](https://t.me/shivayadavv)

[![instagram](https://img.shields.io/badge/CONTACT-INSTAGRAM-red)](https://instagram.com/shivaya.dav)


## Disclaimer

Devolper Provides no warranty with this software and will not be responsible for any direct or indirect damage caused due to the usage of this tool.
Dogerat is built for both Educational and Internal use ONLY.
- Make sure the instagram username is @shvaya.dav and Telegram shivaya_dav beware from scam



## ALCOHOL SUPPORT 
!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)
- Bitcoin
- 1LeLwYyDHu51875aenZaNcEnMrEbHwEKJd
- Usdt trc20
- TWX456AoupoYKwCYUKk3ZMWJtNJZRRHnrp
